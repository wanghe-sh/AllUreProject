﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Allure.Data
{
    public interface IRepository<TEntity> where TEntity : class
    {
        void Create(TEntity entity);

        IQueryable<TEntity> List(Expression<Func<TEntity, bool>> predicate);

        void Update(TEntity entity);

        void Delete(Expression<Func<TEntity, bool>> predicate);
    }
}
