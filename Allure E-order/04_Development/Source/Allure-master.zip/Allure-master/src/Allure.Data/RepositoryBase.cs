﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Allure.Data
{
    public abstract class RepositoryBase<TEntity> : IRepository<TEntity> where TEntity : class
    {
        public void Create(TEntity entity)
        {
            using (var context = new AllureDbContext())
            {
                context.Set<TEntity>().Add(entity);
                context.SaveChanges();
            }
        }

        public IQueryable<TEntity> List(Expression<Func<TEntity, bool>> predicate)
        {
            using (var context = new AllureDbContext())
            {
                return context.Set<TEntity>().Where(predicate);
            }
        }

        public void Update(TEntity entity)
        {
            using (var context = new AllureDbContext())
            {
                context.Entry<TEntity>(entity).State = EntityState.Modified;
                context.SaveChanges();
            }
        }

        public void Delete(System.Linq.Expressions.Expression<Func<TEntity, bool>> predicate)
        {
            throw new NotImplementedException();
        }
    }
}
