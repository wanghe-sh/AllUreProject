﻿using Allure.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Allure.Data
{
    [DbConfigurationType(typeof(AllureDbConfiguration))]
    public class AllureDbContext : DbContext
    {        
        public AllureDbContext() : base("Allure") { }

        public DbSet<User> Users { get; set; }
    }
}
