﻿using Allure.Core;
using Allure.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Allure.UI.Controllers
{
    public partial class HomeController : Controller
    {
        private readonly IUserService _userService;

        public HomeController(IUserService userService)
        {
            _userService = userService;
        }

        public virtual ActionResult Index()
        {
            _userService.ChangePassword(new User { Id = 5, UserName = "id5username", Password = DateTime.Now.ToString() });
            return View();
        }

        public virtual ActionResult About()
        {
            ViewBag.Message = "Your app description page.";

            return View();
        }

        public virtual ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        public virtual ActionResult Another()
        {
            return Content("another");
        }
    }
}
