﻿using Allure.Common.Unity;
using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Unity.Mvc4;

namespace Allure.Web
{
    public abstract class UnityHttpApplication : HttpApplication
    {
        protected void Application_Start()
        {
            InitialzeUnity();
            OnApplicationStart();
        }

        protected virtual void OnApplicationStart()        
        {        
        }

        private void InitialzeUnity()
        {
            var container = new UnityContainer();
            container.AddNewExtension<AutowireExtension>();
            DependencyResolver.SetResolver(new UnityDependencyResolver(container));
        }
    }
}