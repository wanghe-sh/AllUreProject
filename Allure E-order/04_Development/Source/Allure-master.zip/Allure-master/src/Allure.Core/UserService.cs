﻿using Allure.Common.Unity;
using Allure.Data;
using Allure.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Allure.Core
{
    [Autowire(typeof(IUserService))]
    class UserService : IUserService
    {
        private readonly UserRepository _userRepository;

        public UserService(UserRepository userRepository)
        {
            _userRepository = userRepository;
        }

        void IUserService.CreateUser(User user)
        {
            _userRepository.Create(user);
        }

        void IUserService.ChangePassword(User user)
        {
            _userRepository.Update(user);
        }
    }
}
