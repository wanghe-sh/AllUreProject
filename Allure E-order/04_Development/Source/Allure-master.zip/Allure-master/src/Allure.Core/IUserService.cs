﻿using Allure.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Allure.Core
{
    public interface IUserService
    {
        void CreateUser(User user);

        void ChangePassword(User user);
    }
}
