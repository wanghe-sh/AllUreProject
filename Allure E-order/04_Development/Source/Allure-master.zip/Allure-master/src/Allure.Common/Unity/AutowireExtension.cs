﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Practices.Unity;
using System.Reflection;
using System.IO;

namespace Allure.Common.Unity
{
    public class AutowireExtension : UnityContainerExtension
    {
        protected override void Initialize()
        {
            foreach (var assembly in this.GetAssemblies())
            {
                foreach (var type in assembly.GetTypes())
                {
                    foreach (AutowireAttribute autowire in type.GetCustomAttributes(typeof(AutowireAttribute)))
                    {
                        this.Container.RegisterType(autowire.From, type, autowire.Name, this.CreateLifetimeManager(autowire.Lifetime));
                    }
                }
            }
        }

        private Assembly[] GetAssemblies()
        {
            var path = AppDomain.CurrentDomain.RelativeSearchPath;
            if (string.IsNullOrWhiteSpace(path))
            {
                path = AppDomain.CurrentDomain.BaseDirectory;
            }

            var assemblies = new List<Assembly>();

            foreach (var file in Directory.EnumerateFiles(path, "*.dll"))
            {
                try
                {
                    var assembly = Assembly.Load(Path.GetFileNameWithoutExtension(file));

                    if (!IsSystemAssembly(assembly))
                    {
                        assemblies.Add(assembly);
                    }
                }
                catch { }
            }

            return assemblies.ToArray();
        }

        private bool IsSystemAssembly(Assembly assembly)
        {
            return assembly == null
                || assembly.FullName.StartsWith("mscorlib.")
                || assembly.FullName.StartsWith("System.")
                || assembly.FullName.StartsWith("Microsoft.");
        }

        private LifetimeManager CreateLifetimeManager(Lifetime lifetime)
        {
            switch (lifetime)
            {
                case Lifetime.Transient:
                    return this.Container.Resolve<TransientLifetimeManager>();

                case Lifetime.PerThread:
                    return this.Container.Resolve<PerThreadLifetimeManager>();

                default:
                    return this.Container.Resolve<ContainerControlledLifetimeManager>();
            }
        }
    }
}
