﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Allure.Common
{
    class AppSettings
    {
        public string ApplicationName
        {
            get { return "Allure"; }
        }
    }
}
